import React from 'react'

function About() {
  return (
    <div>
        <h2>About Us</h2>
      <p class= "text">To inspire girls at a young age we want to create a platform that transforms 
      the way girls perceive code education and software engineering. The game should be designed
      to teach girls practical, real-world coding skills via highly gamified, story-driven gameplay. 
     This game should be able to teach basics of programming and development languages</p>
         
          <p class= "text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laborum, fugit. Aperiam dignissimos voluptates praesentium fugit facere maiores, dolorum obcaecati maxime.
          </p>
          <p class= "text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laborum, fugit. Aperiam dignissimos voluptates praesentium fugit facere maiores, dolorum obcaecati maxime.
          </p>
          <p class= "text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laborum, fugit. Aperiam dignissimos voluptates praesentium fugit facere maiores, dolorum obcaecati maxime.
          </p>
          <p class= "text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laborum, fugit. Aperiam dignissimos voluptates praesentium fugit facere maiores, dolorum obcaecati maxime.
          </p>
          <p class= "text">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laborum, fugit. Aperiam dignissimos voluptates praesentium fugit facere maiores, dolorum obcaecati maxime.
          </p>
  </div>
  )
}

export default About